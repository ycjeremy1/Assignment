package AbstractShape.java;

public interface Collision
{
    boolean intersect(Point p);
    boolean intersect(LineSeg line);
    boolean intersect(Rectangle rect);
    boolean intersect(Circle circle);
}