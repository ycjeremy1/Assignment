package AbstractShape.java;

public class LineSeg extends AbstractShape implements Collision {
    private Point begin;
    private Point end;

    public LineSeg(Point begin, Point end) {
        this.begin = begin;
        this.end = end;
    }

    public Point getBegin() {
        return begin;
    }

    public Point getEnd() {
        return end;
    }

    @Override
    public boolean intersect(Point p) {
        double x1 = begin.getX();
        double y1 = begin.getY();
        double x2 = end.getX();
        double y2 = end.getY();
        double px = p.getX();
        double py = p.getY();

        if (x1 == x2) {
            // 检查点是否有相同的 x 坐标并在 y 范围内
            return (px == x1) && (Math.min(y1, y2) <= py && py <= Math.max(y1, y2));
        }

        // 计算斜率 m 和截距 b
        double m = (y2 - y1) / (x2 - x1);
        double b = y1 - m * x1;

        // 检查点是否在直线上
        if (py == (m * px + b)) {
            // 检查点是否在 x 和 y 的范围内
            return (Math.min(x1, x2) <= px && px <= Math.max(x1, x2)) &&
                   (Math.min(y1, y2) <= py && py <= Math.max(y1, y2));
        }

        return false;
    }

    @Override
    public boolean intersect(LineSeg line) {
        Point p1 = this.begin;
        Point p2 = this.end;
        Point q1 = line.getBegin();
        Point q2 = line.getEnd();

        // 直接计算叉积
        double d1 = (q1.getX() - p1.getX()) * (p2.getY() - p1.getY()) - (q1.getY() - p1.getY()) * (p2.getX() - p1.getX());
        double d2 = (q2.getX() - p1.getX()) * (p2.getY() - p1.getY()) - (q2.getY() - p1.getY()) * (p2.getX() - p1.getX());
        double d3 = (p1.getX() - q1.getX()) * (q2.getY() - q1.getY()) - (p1.getY() - q1.getY()) * (q2.getX() - q1.getX());
        double d4 = (p2.getX() - q1.getX()) * (q2.getY() - q1.getY()) - (p2.getY() - q1.getY()) * (q2.getX() - q1.getX());

        // 检查叉积符号
        if ((d1 * d2 < 0) && (d3 * d4 < 0)) {
            return true; // 两条线段相交
        }

        // 共线情况，检查是否重叠
        if (d1 == 0 && Math.min(p1.getX(), p2.getX()) <= q1.getX() && q1.getX() <= Math.max(p1.getX(), p2.getX()) &&
            Math.min(p1.getY(), p2.getY()) <= q1.getY() && q1.getY() <= Math.max(p1.getY(), p2.getY())) return true;
        if (d2 == 0 && Math.min(p1.getX(), p2.getX()) <= q2.getX() && q2.getX() <= Math.max(p1.getX(), p2.getX()) &&
            Math.min(p1.getY(), p2.getY()) <= q2.getY() && q2.getY() <= Math.max(p1.getY(), p2.getY())) return true;
        if (d3 == 0 && Math.min(q1.getX(), q2.getX()) <= p1.getX() && p1.getX() <= Math.max(q1.getX(), q2.getX()) &&
            Math.min(q1.getY(), q2.getY()) <= p1.getY() && p1.getY() <= Math.max(q1.getY(), q2.getY())) return true;
        if (d4 == 0 && Math.min(q1.getX(), q2.getX()) <= p2.getX() && p2.getX() <= Math.max(q1.getX(), q2.getX()) &&
            Math.min(q1.getY(), q2.getY()) <= p2.getY() && p2.getY() <= Math.max(q1.getY(), q2.getY())) return true;

        return false;
    }


    @Override
    public boolean intersect(Rectangle rect) {
        double x1 = begin.getX();
        double y1 = begin.getY();
        double x2 = end.getX();
        double y2 = end.getY();

        // 检查起点或终点是否在矩形的边界内
        boolean isStartInside = (x1 >= rect.getLeft() && x1 <= rect.getRight() && y1 >= rect.getBottom() && y1 <= rect.getTop());
        boolean isEndInside = (x2 >= rect.getLeft() && x2 <= rect.getRight() && y2 >= rect.getBottom() && y2 <= rect.getTop());

        // 如果起点或终点在矩形内，则判定为碰撞
        return isStartInside || isEndInside;
    }
    @Override
    public boolean intersect(Circle circle) {
        // 获取线段的起点和终点坐标
        double x1 = this.begin.getX();
        double y1 = this.begin.getY();
        double x2 = this.end.getX();
        double y2 = this.end.getY();
        
        // 获取圆心和半径
        double cx = circle.getCenter().getX();
        double cy = circle.getCenter().getY();
        double r = circle.getRadius();

        // 计算 t 值
        double dx = x2 - x1;
        double dy = y2 - y1;
        double t = ((cx - x1) * dx + (cy - y1) * dy) / (dx * dx + dy * dy);

        // 限制 t 的范围在 [0, 1]
        t = Math.max(0, Math.min(1, t));

        // 计算投影点 P 的坐标
        double closestX = x1 + t * dx;
        double closestY = y1 + t * dy;

        // 计算投影点 P 和圆心 C 之间的距离
        double distance = Math.sqrt((closestX - cx) * (closestX - cx) + (closestY - cy) * (closestY - cy));

        // 判断是否相交
        return distance <= r;
    }

    
        

    
}
