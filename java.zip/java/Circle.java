package AbstractShape.java;

public class Circle extends AbstractShape implements Collision {

    private Point center;
    private float radius;

    // 默认构造方法
    public Circle() {
        this.center = new Point(0, 0);
        this.radius = 1.0f;
    }

    // 带参构造方法
    public Circle(Point center, float radius) {
        this.center = center;
        this.radius = radius;
    }

    public Point getCenter() {
        return center;
    }

    public float getRadius() {
        return radius;
    }

    @Override
    public boolean intersect(Point p) {
        double dx = p.getX() - center.getX();
        double dy = p.getY() - center.getY();
        double distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= radius;
    }

    @Override
    public boolean intersect(LineSeg line) {
        // 获取线段的起点和终点坐标
        double x1 = line.getBegin().getX();
        double y1 = line.getBegin().getY();
        double x2 = line.getEnd().getX();
        double y2 = line.getEnd().getY();

        // 获取圆心和半径
        double cx = center.getX();
        double cy = center.getY();
        double r = radius;

        // 计算 t 值
        double dx = x2 - x1;
        double dy = y2 - y1;
        double t = ((cx - x1) * dx + (cy - y1) * dy) / (dx * dx + dy * dy);

        // 限制 t 的范围在 [0, 1]
        t = Math.max(0, Math.min(1, t));

        // 计算投影点 P 的坐标
        double closestX = x1 + t * dx;
        double closestY = y1 + t * dy;

        // 计算投影点 P 和圆心 C 之间的距离
        double distance = Math.sqrt((closestX - cx) * (closestX - cx) + (closestY - cy) * (closestY - cy));

        // 判断是否相交
        return distance <= r;
    }

    @Override
    public boolean intersect(Rectangle rect) {
        double closestX = Math.max(rect.getLeft(), Math.min(center.getX(), rect.getRight()));
        double closestY = Math.max(rect.getBottom(), Math.min(center.getY(), rect.getTop()));
        double deltaX = closestX - center.getX();
        double deltaY = closestY - center.getY();
        return (deltaX * deltaX + deltaY * deltaY) <= (radius * radius);
    }

    @Override
    public boolean intersect(Circle circle2) {
        double dx = this.center.getX() - circle2.getCenter().getX();
        double dy = this.center.getY() - circle2.getCenter().getY();
        double distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= (this.radius + circle2.getRadius());
    }
}
