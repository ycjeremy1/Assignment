package AbstractShape.java;

public class Rectangle extends AbstractShape implements Collision {

    private float left;
    private float right;
    private float top;
    private float bottom;

    public Rectangle(float left, float right, float top, float bottom) {
        this.left = left;
        this.right = right;
        this.top = top;
        this.bottom = bottom;
    }

    public float getLeft() {
        return left;
    }

    public float getRight() {
        return right;
    }

    public float getTop() {
        return top;
    }

    public float getBottom() {
        return bottom;
    }

    // 实现 CollisionDetector 接口中的方法
    @Override
    public boolean intersect(Point p) {
        return p.getX() > left && p.getX() < right && p.getY() > bottom && p.getY() < top;
    }

    @Override
    public boolean intersect(LineSeg line) {
        // 这里可以实现线段与矩形的相交逻辑
        return false; // 示例返回值
    }

    @Override
    public boolean intersect(Rectangle rect2) {
        return this.left < rect2.getRight() && this.right > rect2.getLeft() &&
               this.top > rect2.getBottom() && this.bottom < rect2.getTop();
    }

    @Override
    public boolean intersect(Circle circle) {
        double closestX;
        if (circle.getCenter().getX() < this.left) {
            closestX = this.left;
        } else if (circle.getCenter().getX() > this.right) {
            closestX = this.right;
        } else {
            closestX = circle.getCenter().getX();
        }

        double closestY;
        if (circle.getCenter().getY() < this.bottom) {
            closestY = this.bottom;
        } else if (circle.getCenter().getY() > this.top) {
            closestY = this.top;
        } else {
            closestY = circle.getCenter().getY();
        }
        double deltaX = closestX - circle.getCenter().getX();
        double deltaY = closestY - circle.getCenter().getY();
        double distanceSquared = deltaX * deltaX + deltaY * deltaY;
        return distanceSquared <= circle.getRadius() * circle.getRadius();
    }
}
