package AbstractShape.java;

public class main {
    public static void main(String[] args) {
        // 创建一些测试对象
        Point p1 = new Point(1.0f, 2.0f);
        Point p2 = new Point(1.0f, 2.0f);
        Point p3 = new Point(3.0f, 4.0f);
        
        LineSeg line = new LineSeg(new Point(0.0f, 0.0f), new Point(5.0f, 5.0f));
        
        Circle circle = new Circle(new Point(2.0f, 2.0f), 3.0f);
        
        Rectangle rect = new Rectangle(1.0f, 4.0f, 4.0f, 1.0f);
        
        // Testing Point intersect methods
        System.out.println("p1 intersects p2: " + p1.intersect(p2)); // Should be true
        System.out.println("p1 intersects p3: " + p1.intersect(p3)); // Should be false
        
        // Testing Point-LineSeg intersection
        System.out.println("p1 intersects line: " + p1.intersect(line)); // Check if point lies on the line
        
        // Testing Point-Circle intersection
        System.out.println("p1 intersects circle: " + p1.intersect(circle)); // Check if point is within the circle radius
        
        // Testing Rectangle intersections
        System.out.println("rect intersects p1: " + rect.intersect(p1)); // Check if point lies within rectangle
        System.out.println("rect intersects line: " + rect.intersect(line)); // Check if rectangle intersects with line
        System.out.println("rect intersects circle: " + rect.intersect(circle)); // Check if rectangle intersects with circle

        // Testing LineSeg intersections
        System.out.println("line intersects p3: " + line.intersect(p3)); // Check if line intersects with point
        System.out.println("line intersects circle: " + line.intersect(circle)); // Check if line intersects with circle
        System.out.println("line intersects rect: " + line.intersect(rect)); // Check if line intersects with rectangle

        // Testing Circle intersections
        System.out.println("circle intersects p1: " + circle.intersect(p1)); // Check if circle contains point
        System.out.println("circle intersects line: " + circle.intersect(line)); // Check if circle intersects line
        System.out.println("circle intersects rect: " + circle.intersect(rect)); // Check if circle intersects rectangle
        System.out.println("circle intersects another circle: " + circle.intersect(new Circle(new Point(5.0f, 5.0f), 2.0f))); // Check if circles intersect

        // Print instance counts
        System.out.println("Number of Point instances: " + Point.getNumberOfInstances());
        System.out.println("Number of Rectangle instances: " + Rectangle.getNumOfInstances());
        System.out.println("Number of LineSeg instances: " + LineSeg.getNumOfInstances());
        System.out.println("Number of Circle instances: " + Circle.getNumOfInstances());
    }
}
