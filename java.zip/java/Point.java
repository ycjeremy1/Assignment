package AbstractShape.java;

public class Point extends AbstractShape implements Collision {
    private float x = 0;
    private float y = 0;
    private static int numberOfInstances = 0;

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
        numberOfInstances++;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public static int getNumberOfInstances() {
        return numberOfInstances;
    }

    @Override
    public boolean intersect(Point p) {
        return this.x == p.getX() && this.y == p.getY();
    }

    @Override
    public boolean intersect(LineSeg line) {
        Point q1 = line.getBegin();
        Point q2 = line.getEnd();

        // 检查当前点是否在线段 q1-q2 之间
        double crossProduct = (this.y - q1.getY()) * (q2.getX() - q1.getX()) - (this.x - q1.getX()) * (q2.getY() - q1.getY());

        // 如果叉积不为 0，则点不在线段上
        if (Math.abs(crossProduct) > 1e-6) {
            return false;
        }

        // 检查点是否在 q1 和 q2 之间的范围内
        double dotProduct = (this.x - q1.getX()) * (q2.getX() - q1.getX()) + (this.y - q1.getY()) * (q2.getY() - q1.getY());
        if (dotProduct < 0) {
            return false;
        }

        double squaredLengthQ1Q2 = (q2.getX() - q1.getX()) * (q2.getX() - q1.getX()) + (q2.getY() - q1.getY()) * (q2.getY() - q1.getY());
        if (dotProduct > squaredLengthQ1Q2) {
            return false;
        }

        return true;
    }

    @Override
    public boolean intersect(Circle circle) {
        double dx = this.x - circle.getCenter().getX();
        double dy = this.y - circle.getCenter().getY();
        double distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= circle.getRadius();
    }

    @Override
    public boolean intersect(Rectangle rect) {
        return false;
    }
}


